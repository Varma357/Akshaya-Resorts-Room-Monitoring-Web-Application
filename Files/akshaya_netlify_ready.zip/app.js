
/* ---------------------------- Full Rebuild JS (charts removed) ---------------------------- */

/* ----------------- Config & Layout data ----------------- */
const ADMIN_PASS = 'Akshaya@123';
const STAFF_PASS = 'Resort@123';
const STORAGE_KEY = 'akshaya_roomdata_v2';
const LOG_KEY = 'akshaya_activity_v2';

const blockFloors = {
  A: { 'Ground': ['A1','A2','A3','A4','A5','A6','A7'], '1st Floor': ['A27','A28','A29','A30','A31','A32','A33'], '2nd Floor': ['A53','A54','A55','A56','A57','A58','A59'] },
  B: { 'Ground': ['B8','B9','B10','B11','B12','B13'], '1st Floor': ['B34','B35','B36','B37','B38','B39'], '2nd Floor': ['B60','B61','B62','B63','B64','B65'], '3rd Floor': ['B79','B80','B81','B82','B83','B84'] },
  C: { 'Ground': ['C14','C15','C16','C17','C18','C19'], '1st Floor': ['C40','C41','C42','C43','C44','C45'], '2nd Floor': ['C66','C67','C68','C69','C70','C71'], '3rd Floor': ['C85','C86','C87','C88','C89','C90'] },
  D: { 'Ground': ['D20','D21','D22','D23','D24','D25','D26'], '1st Floor': ['D46','D47','D48','D49','D50','D51','D52'], '2nd Floor': ['D72','D73','D74','D75','D76','D77','D78'] }
};

const desiredOrder = [
  "A1","A2","A3","A4","A5","A6","A7",
  "B8","B9","B10","B11","B12","B13",
  "C14","C15","C16","C17","C18","C19",
  "D20","D21","D22","D23","D24","D25","D26",
  "A27","A28","A29","A30","A31","A32","A33",
  "B34","B35","B36","B37","B38","B39",
  "C40","C41","C42","C43","C44","C45",
  "D46","D47","D48","D49","D50","D51","D52",
  "A53","A54","A55","A56","A57","A58","A59",
  "B60","B61","B62","B63","B64","B65",
  "C66","C67","C68","C69","C70","C71",
  "D72","D73","D74","D75","D76","D77","D78",
  "B79","B80","B81","B82","B83","B84",
  "C85","C86","C87","C88","C89","C90"
];

const fullRooms = Array.from(new Set(desiredOrder.concat(Object.values(blockFloors).flatMap(f=>Object.values(f).flat()))));

/* ----------------- State ----------------- */
let roomData = {};     // { "A1": { works: { "Electrical": [ subObjs... ] (array has _images property for work-level images) }, /* no roomImage */ } }
let activityLog = [];
let currentRole = 'viewer';
let currentRoom = null;
let currentSort = { col:'room', dir:1 };
let debounceTimer = null;
let toastTimer = null;

/* ----------------- Storage helpers ----------------- */
function loadState(){
  try{ roomData = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch(e){ roomData = {}; }
  try{ activityLog = JSON.parse(localStorage.getItem(LOG_KEY)) || []; } catch(e){ activityLog = []; }
}
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(roomData)); }
function saveLog(){ localStorage.setItem(LOG_KEY, JSON.stringify(activityLog)); }
function addLog(text){ activityLog.unshift({time:new Date().toISOString(), text}); if(activityLog.length>500) activityLog.length=500; saveLog(); renderActivityLog(); }

/* ----------------- UI utilities ----------------- */
function showToast(txt, ms=1400){ const el=document.getElementById('toast'); el.textContent=txt; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'), ms); }
function debounce(fn, ms=200){ clearTimeout(debounceTimer); debounceTimer=setTimeout(fn, ms); }

/* ----------------- Init wiring ----------------- */
document.addEventListener('DOMContentLoaded', init);
function init(){
  loadState();
  // buttons
  document.getElementById('btnView').addEventListener('click', showView);
  document.getElementById('btnDashboard').addEventListener('click', openDashboard);
  document.getElementById('roleLoginBtn').addEventListener('click', roleLogin);
  document.getElementById('themeToggle').addEventListener('click', toggleTheme);

  // filters & search
  document.getElementById('filterRoom').addEventListener('change', renderViewTable);
  document.getElementById('filterWork').addEventListener('change', renderViewTable);
  document.getElementById('filterStatus').addEventListener('change', renderViewTable);
  document.getElementById('filterSearch').addEventListener('input', ()=>debounce(renderViewTable,220));
  document.getElementById('roomSearch').addEventListener('input', ()=>debounce(highlightSearch,200));
  document.getElementById('jumpBtn').addEventListener('click', jumpToMatch);
  document.getElementById('clearSearchBtn').addEventListener('click', ()=>{ document.getElementById('roomSearch').value=''; highlightSearch(); });

  document.getElementById('exportJsonBtn').addEventListener('click', exportJSON);
  document.getElementById('importJsonBtn').addEventListener('click', ()=>document.getElementById('importJson').click());
  document.getElementById('importJson').addEventListener('change', handleImport);

  document.getElementById('downloadXlsxBtn').addEventListener('click', exportToXLSX);
  document.getElementById('clearLogBtn').addEventListener('click', ()=>{ if(confirm('Clear activity log?')){ activityLog=[]; saveLog(); renderActivityLog(); showToast('Log cleared'); }});

  document.getElementById('selectAllRooms').addEventListener('change', onSelectAllRooms);
  document.getElementById('selectAllWorks').addEventListener('change', onSelectAllWorks);
  document.getElementById('clearFiltersBtn').addEventListener('click', clearFilters);
  document.getElementById('printBtn').addEventListener('click', ()=>window.print());

  // room modal buttons
  document.getElementById('closeRoomBtn').addEventListener('click', closeRoomModal);
  document.getElementById('addWorkBtn').addEventListener('click', addWorkFromModal);
  document.getElementById('applyAllWorkBtn').addEventListener('click', applyWorkToAllFromModal);
  document.getElementById('saveRoomBtn').addEventListener('click', ()=>{ saveState(); renderViewTable(); closeRoomModal(); });
  document.getElementById('markAllDoneBtn').addEventListener('click', markAllDoneForCurrentRoom);
  document.getElementById('copyFromBtn').addEventListener('click', copyFromRoomDialog);

  // initial renders
  populateFilterOptions();
  renderGlobalWorkPanel();
  renderStats();
  renderViewTable();
  renderActivityLog();
}

/* ----------------- Role & theme ----------------- */
function roleLogin(){
  const selected = document.getElementById('roleSelect').value;
  if(selected==='viewer'){ currentRole='viewer'; showToast('Role: Viewer'); renderViewTable(); return; }
  const pw = prompt(`Enter password for ${selected}`);
  if(pw===null) return;
  if((selected==='admin' && pw===ADMIN_PASS)||(selected==='staff' && pw===STAFF_PASS)){ currentRole=selected; showToast('Role: '+selected); renderViewTable(); }
  else alert('Wrong password');
}
function toggleTheme(){
  document.body.classList.toggle('dark');
  showToast('Theme toggled');
}

/* ----------------- Stats ----------------- */
function computeStats(){
  let totalRooms = fullRooms.length;
  let totalWorks = 0, completed=0, wip=0, pending=0;
  fullRooms.forEach(r=>{
    const works = roomData[r]?.works || {};
    Object.entries(works).forEach(([workName, arr])=>{
      if(!workName || !workName.trim()) return;
      arr.forEach(s=>{
        totalWorks++;
        const st = (s.status||'').toLowerCase();
        if(st.includes('completed')) completed++;
        else if(st.includes('work')) wip++;
        else if(st.includes('pending')) pending++;
      });
    });
  });
  const overallPct = totalWorks ? Math.round((completed/totalWorks)*100) : 0;
  return { totalRooms, totalWorks, completed, wip, pending, overallPct };
}

function renderStats(){
  const st = computeStats();
  const panel = document.getElementById('statsPanel'); panel.innerHTML='';
  const boxes = [
    { title:'Total Rooms', val: st.totalRooms, action: ()=>showRoomsList(fullRooms) },
    { title:'Total Works', val: st.totalWorks, action: ()=>{ document.getElementById('filterWork').value=''; renderViewTable(); showView(); } },
    { title:'Completed', val: st.completed, action: ()=>showStatusRooms('Completed') },
    { title:'Work in Progress', val: st.wip, action: ()=>showStatusRooms('Work in Progress') },
    { title:'Pending', val: st.pending, action: ()=>showStatusRooms('Pending') },
    { title:'Overall %', val: st.overallPct + '%', action: ()=>{} }
  ];
  boxes.forEach(b=>{
    const el = document.createElement('div'); el.className='stat';
    el.innerHTML = `<div style="font-weight:700">${b.val}</div><div class="small-muted">${b.title}</div>`;
    el.onclick = b.action;
    panel.appendChild(el);
  });
}

/* ----------------- Blocks & rooms list ----------------- */
function renderBlocks(){
  const el = document.getElementById('floorsContainer'); el.innerHTML='';
  Object.keys(blockFloors).forEach(b=>{
    const box = document.createElement('div'); box.className='panel';
    const lbl = document.createElement('div'); lbl.innerHTML = `<div class="label">Block ${b}</div>`;
    box.appendChild(lbl);
    const btnRow = document.createElement('div'); btnRow.style.marginTop='8px';
    Object.keys(blockFloors[b]).forEach(f=>{
      const btn = document.createElement('button'); btn.className='btn'; btn.textContent = `${f} (${blockFloors[b][f].length})`;
      btn.style.marginRight='6px';
      btn.onclick = ()=>showRooms(b,f);
      btnRow.appendChild(btn);
    });
    box.appendChild(btnRow);
    el.appendChild(box);
  });
}

function showRooms(blockKey, floorName){
  const rooms = blockFloors[blockKey][floorName] || [];
  const rc = document.getElementById('roomsContainer'); rc.innerHTML = `<h4>${blockKey} — ${floorName}</h4>`;
  const grid = document.createElement('div'); grid.className='room-grid';
  rooms.forEach(r=>{
    const info = getRoomSummary(r);
    const percent = info.total ? Math.round((info.completed/info.total)*100) : 0;
    let color='rgba(200,200,200,0.12)'; if(info.total===0) color='rgba(0,0,0,0.04)'; else if(info.completed===info.total) color= 'var(--green)'; else if(info.completed>0) color='var(--yellow)'; else color='var(--red)';
    const card = document.createElement('div'); card.className='room-card';
    card.innerHTML = `<strong>${r}</strong><div class="room-badge" style="background:${color};color:#fff">${info.total?info.status:'No works'}</div>
      <div class="small-muted">${info.total} works</div>
      <div class="room-progress"><div style="width:${percent}%;height:100%;background:${color}"></div></div>
      <div style="margin-top:8px;display:flex;gap:8px"><button class="btn" data-room="${r}" data-action="open">Open</button><button class="btn" data-room="${r}" data-action="quick">+Work</button></div>`;
    grid.appendChild(card);
  });
  rc.appendChild(grid);
  rc.querySelectorAll('button[data-action="open"]').forEach(b=>b.addEventListener('click', e=> openRoomModal(e.target.dataset.room)));
  rc.querySelectorAll('button[data-action="quick"]').forEach(b=>b.addEventListener('click', e=> quickAddWork(e.target.dataset.room)));
}

/* ----------------- Room modal & editing ----------------- */
function openRoomModal(room){
  if(currentRole !== 'admin'){ alert('Only Admin can edit rooms'); return; }
  currentRoom = room;
  if(!roomData[room]) roomData[room] = { works: {} };
  document.getElementById('roomTitle').textContent = `Room ${room}`;
  document.getElementById('roomSubtitle').textContent = `ID: ${room}`;
  renderWorkContainer();
  document.getElementById('roomModal').style.display = 'block';
}
function closeRoomModal(){ document.getElementById('roomModal').style.display = 'none'; currentRoom = null; }

function addWorkFromModal(){
  if(!currentRoom) return;
  const name = document.getElementById('newWorkInput').value.trim();
  if(!name) return alert('Enter work name');
  if(!roomData[currentRoom]) roomData[currentRoom] = { works: {} };
  if(!roomData[currentRoom].works[name]) roomData[currentRoom].works[name] = [];
  // ensure work-level images array (attached to array object)
  if(!roomData[currentRoom].works[name]._images) roomData[currentRoom].works[name]._images = [];
  const applyAll = confirm('Apply this Work to ALL rooms? (creates the work where missing)');
  if(applyAll){ fullRooms.forEach(r=>{ if(!roomData[r]) roomData[r] = { works:{} }; if(!roomData[r].works[name]) { roomData[r].works[name] = []; roomData[r].works[name]._images = []; } }); addLog(`Work "${name}" applied to ALL rooms by ${currentRole}`); }
  else addLog(`Work "${name}" added to ${currentRoom} by ${currentRole}`);
  document.getElementById('newWorkInput').value='';
  saveState(); populateFilterOptions(); renderWorkContainer(); renderViewTable(); renderGlobalWorkPanel(); renderStats();
}

function applyWorkToAllFromModal(){
  const name = prompt('Work name to apply to ALL rooms');
  if(!name) return;
  fullRooms.forEach(r=>{ if(!roomData[r]) roomData[r] = { works:{} }; if(!roomData[r].works[name]) { roomData[r].works[name] = []; roomData[r].works[name]._images = []; } });
  addLog(`Applied work "${name}" to ALL rooms by ${currentRole}`);
  saveState(); populateFilterOptions(); renderWorkContainer(); renderViewTable(); renderGlobalWorkPanel(); renderStats();
}

/* Note: removed addRoomImageFromModal — room-level images not allowed */

function renderWorkContainer(){
  const container = document.getElementById('workContainer'); container.innerHTML='';
  const works = roomData[currentRoom]?.works || {};
  const keys = Object.keys(works).sort();
  if(keys.length===0){ container.innerHTML = '<div class="small-muted">No works yet</div>'; return; }
  keys.forEach(workName=>{
    const wRow = document.createElement('div'); wRow.style.marginBottom='10px';
    const heading = document.createElement('div'); heading.style.display='flex'; heading.style.justifyContent='space-between'; heading.style.alignItems='center';
    // work-level images: show thumbnail + camera + delete icon
    const workImages = works[workName]._images || [];
    const workImgHtml = workImages.length>0 ? `<div class="img-wrap"><img src="${workImages[0]}" class="room-image"/><span class="delete-icon" title="Delete work image" data-room="${currentRoom}" data-work="${workName}" data-level="work">🗑️</span></div>` : `<div class="small-muted">No image</div>`;
    heading.innerHTML = `<div style="font-weight:700">${workName} <span class="small-muted">(${works[workName].length})</span></div>
      <div style="display:flex;gap:8px;align-items:center">
        ${workImgHtml}
        <button class="btn" data-act="addworkimg" data-work="${workName}">📷</button>
        <button class="btn" data-act="addsub" data-work="${workName}">+ Sub Work</button>
        <button class="btn" data-act="rename" data-work="${workName}">Rename</button>
        <button class="btn" data-act="delete" data-work="${workName}">Delete</button>
      </div>`;
    wRow.appendChild(heading);

    const subList = document.createElement('div'); subList.style.marginTop='8px';
    works[workName].forEach((subObj, idx)=>{
      const subRow = document.createElement('div'); subRow.style.display='flex'; subRow.style.gap='8px'; subRow.style.alignItems='center'; subRow.style.marginBottom='6px';
      const nameDiv = document.createElement('div'); nameDiv.textContent = subObj.name || '(unnamed)'; nameDiv.style.minWidth='160px';
      const statusSel = document.createElement('select'); ['', 'Completed','Work in Progress','Pending'].forEach(opt=>{ const o = document.createElement('option'); o.value=o.text=opt; if(opt===subObj.status) o.selected=true; statusSel.appendChild(o); });
      statusSel.addEventListener('change', ()=>{ subObj.status = statusSel.value; saveState(); addLog(`Status updated for ${currentRoom} - ${workName}/${subObj.name} -> ${subObj.status}`); renderViewTable(); renderStats(); });

      const purpose = document.createElement('input'); purpose.value = subObj.purpose || ''; purpose.placeholder='Purpose'; purpose.className='input'; purpose.style.width='150px';
      purpose.addEventListener('blur', ()=>{ subObj.purpose = purpose.value.trim(); saveState(); });

      const remarks = document.createElement('input'); remarks.value = subObj.remarks || ''; remarks.placeholder='Remarks'; remarks.className='input'; remarks.style.width='150px';
      remarks.addEventListener('blur', ()=>{ subObj.remarks = remarks.value.trim(); saveState(); });

      // sub-work images (subObj.images array)
      const subImages = subObj.images || [];
      const imgDiv = document.createElement('div');
      if(subImages.length>0){
        imgDiv.innerHTML = `<div class="img-wrap"><img src="${subImages[0]}" class="room-image"/><span class="delete-icon" title="Delete sub-work image" data-room="${currentRoom}" data-work="${workName}" data-sub="${idx}" data-level="sub">🗑️</span></div>`;
      } else imgDiv.innerHTML = '<div class="small-muted">No image</div>';

      const imgBtn = document.createElement('button'); imgBtn.className='btn'; imgBtn.textContent='📷';
      imgBtn.addEventListener('click', ()=>{
        if(currentRole !== 'admin'){ alert('Only Admin can add images'); return; }
        const fi = document.createElement('input'); fi.type='file'; fi.accept='image/*';
        fi.onchange = (ev)=>{ const f = ev.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = (evt)=>{ if(!subObj.images) subObj.images = []; subObj.images.unshift(evt.target.result); saveState(); renderWorkContainer(); addLog(`Image added to ${currentRoom} ${workName}/${subObj.name}`); showToast('Image saved'); }; r.readAsDataURL(f); };
        fi.click();
      });

      const editBtn = document.createElement('button'); editBtn.className='btn'; editBtn.textContent='✏️';
      editBtn.addEventListener('click', ()=>{
        if(currentRole!=='admin'){ alert('Only Admin can edit'); return; }
        const newName = prompt('Edit sub-work name', subObj.name||'');
        if(newName!==null){ subObj.name = newName.trim(); saveState(); renderWorkContainer(); renderViewTable(); addLog(`Renamed sub-work in ${currentRoom} ${workName} -> ${subObj.name}`); }
      });

      const delBtn = document.createElement('button'); delBtn.className='btn'; delBtn.textContent='🗑️';
      delBtn.addEventListener('click', ()=>{ if(currentRole!=='admin'){ alert('Only Admin can delete'); return; } if(!confirm('Delete this sub-work?')) return; roomData[currentRoom].works[workName].splice(idx,1); saveState(); renderWorkContainer(); renderViewTable(); addLog(`Deleted sub-work ${workName} from ${currentRoom}`); });

      subRow.appendChild(nameDiv); subRow.appendChild(editBtn); subRow.appendChild(delBtn); subRow.appendChild(imgBtn);
      subRow.appendChild(statusSel); subRow.appendChild(purpose); subRow.appendChild(remarks); subRow.appendChild(imgDiv);
      subList.appendChild(subRow);
    });

    wRow.appendChild(subList);
    container.appendChild(wRow);

    // wire action buttons
    heading.querySelectorAll('button').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const act = btn.dataset.act, w = btn.dataset.work;
        if(act==='addsub') addSubWorkDialog(w);
        else if(act==='rename') renameWorkDialog(w);
        else if(act==='delete') deleteWorkLocal(w);
        else if(act==='addworkimg') addWorkImage(currentRoom, w);
      });
    });
  });

  // wire delete icons in work-level & sub-level images
  container.querySelectorAll('.delete-icon').forEach(ic=>{
    ic.addEventListener('click', (e)=>{
      const level = ic.dataset.level;
      const room = ic.dataset.room;
      const work = ic.dataset.work;
      if(level==='work'){
        if(!confirm('Delete work image?')) return;
        const arr = roomData[room].works[work];
        if(arr && arr._images && arr._images.length>0){ arr._images.splice(0,1); saveState(); renderWorkContainer(); renderViewTable(); addLog(`Deleted work-level image for ${room} ${work}`); }
      } else if(level==='sub'){
        const subIdx = parseInt(ic.dataset.sub);
        if(!confirm('Delete sub-work image?')) return;
        const sub = roomData[room].works[work][subIdx];
        if(sub && sub.images && sub.images.length>0){ sub.images.splice(0,1); saveState(); renderWorkContainer(); renderViewTable(); addLog(`Deleted sub-work image for ${room} ${work}/${sub.name}`); }
      }
    });
  });
}

/* Sub-work helpers */
function addSubWorkDialog(workName){
  const subName = prompt('Sub-work name (e.g., Replace switch)'); if(!subName) return;
  const applyAll = confirm(`Apply this Sub-work to ALL rooms that already have the work "${workName}"?`);
  if(applyAll){
    fullRooms.forEach(r=>{ if(roomData[r] && roomData[r].works && roomData[r].works[workName]) roomData[r].works[workName].push({ name: subName, status:'', purpose:'', remarks:'', images: [] }); });
    addLog(`Applied sub-work "${subName}" to all rooms with work ${workName}`);
  } else {
    if(!roomData[currentRoom].works[workName]) roomData[currentRoom].works[workName] = [];
    roomData[currentRoom].works[workName].push({ name: subName, status:'', purpose:'', remarks:'', images: [] });
    addLog(`Added sub-work "${subName}" to ${currentRoom}/${workName}`);
  }
  saveState(); renderWorkContainer(); renderViewTable(); renderGlobalWorkPanel(); renderStats();
}
function renameWorkDialog(oldName){
  const newName = prompt('Rename work', oldName); if(!newName) return;
  if(newName.trim()===oldName) return;
  const works = roomData[currentRoom].works;
  works[newName.trim()] = works[oldName];
  // ensure _images array preserved
  if(!works[newName.trim()]._images) works[newName.trim()]._images = works[oldName]._images || [];
  delete works[oldName];
  saveState(); renderWorkContainer(); renderViewTable(); populateFilterOptions(); addLog(`Renamed work ${oldName} -> ${newName} in ${currentRoom}`);
}
function deleteWorkLocal(workName){
  if(!confirm('Delete this work from this room?')) return;
  delete roomData[currentRoom].works[workName];
  saveState(); renderWorkContainer(); renderViewTable(); addLog(`Deleted work ${workName} from ${currentRoom}`);
}

/* add work-level image */
function addWorkImage(room, workName){
  if(currentRole !== 'admin'){ alert('Only Admin can add images'); return; }
  const fi = document.createElement('input'); fi.type='file'; fi.accept='image/*';
  fi.onchange = (ev)=>{ const f = ev.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = (evt)=>{ if(!roomData[room].works[workName]._images) roomData[room].works[workName]._images = []; roomData[room].works[workName]._images.unshift(evt.target.result); saveState(); renderWorkContainer(); addLog(`Work image added to ${room} ${workName}`); showToast('Work image saved'); }; r.readAsDataURL(f); };
  fi.click();
}

/* mark all done & copy */
function markAllDoneForCurrentRoom(){
  if(!currentRoom) return;
  const works = roomData[currentRoom].works || {};
  Object.values(works).forEach(arr=>arr.forEach(s=>s.status='Completed'));
  saveState(); renderWorkContainer(); renderViewTable(); renderStats(); addLog(`Marked all completed in ${currentRoom}`);
}
function copyFromRoomDialog(){
  const from = prompt('Copy works from which room? (e.g., A1)'); if(!from) return;
  if(!roomData[from]) return alert('No data in that room');
  roomData[currentRoom] = JSON.parse(JSON.stringify(roomData[from]));
  // ensure work _images arrays exist if copied
  Object.keys(roomData[currentRoom].works||{}).forEach(w=>{ if(!roomData[currentRoom].works[w]._images) roomData[currentRoom].works[w]._images = (roomData[from].works[w] && roomData[from].works[w]._images) ? roomData[from].works[w]._images.slice() : []; });
  saveState(); renderWorkContainer(); renderViewTable(); addLog(`Copied data from ${from} to ${currentRoom}`);
}

/* quick add */
function quickAddWork(room){
  if(currentRole!=='admin'){ alert('Only Admin can add works'); return; }
  const name = prompt('Quick Add Work name'); if(!name) return;
  if(!roomData[room]) roomData[room] = { works: {} };
  if(!roomData[room].works[name]) roomData[room].works[name] = [];
  if(!roomData[room].works[name]._images) roomData[room].works[name]._images = [];
  addLog(`Quick added work "${name}" to ${room}`);
  saveState(); renderViewTable(); renderStats(); populateFilterOptions();
}

/* ----------------- Filters & Table ----------------- */
function populateFilterOptions(){
  const fr = document.getElementById('filterRoom');
  fr.innerHTML = '<option value="">All Rooms</option>';
  ['A','B','C','D'].forEach(b=>{ const o=document.createElement('option'); o.value=b; o.text = 'Block '+b; fr.appendChild(o); });
  fullRooms.forEach(r=>{ const o=document.createElement('option'); o.value=r; o.text=r; fr.appendChild(o); });

  const workSet = new Set();
  Object.values(roomData).forEach(rd=>{ if(rd.works) Object.keys(rd.works).forEach(w=>{ if(w && w.trim()) workSet.add(w); }); });
  const fw = document.getElementById('filterWork'); fw.innerHTML = '<option value="">All Works</option>';
  Array.from(workSet).sort().forEach(w=>{ const o=document.createElement('option'); o.value=w; o.text=w; fw.appendChild(o); });
}

/* Select all handlers */
function onSelectAllRooms(e){
  const checked = e.target.checked; const fr = document.getElementById('filterRoom');
  if(checked){ fr.value=''; fr.setAttribute('disabled','disabled'); showToast('All rooms selected'); } else fr.removeAttribute('disabled');
  renderViewTable();
}
function onSelectAllWorks(e){
  const checked = e.target.checked; const fw = document.getElementById('filterWork');
  if(checked){ fw.value=''; fw.setAttribute('disabled','disabled'); showToast('All works selected'); } else fw.removeAttribute('disabled');
  renderViewTable();
}

/* Build and render view table */
/* IMPORTANT: do NOT call populateFilterOptions() inside renderViewTable to avoid resetting selections */
function renderViewTable(){
  renderStats(); // keep stats in sync
  const head = document.getElementById('viewHead'); const body = document.getElementById('viewBody');
  head.innerHTML = `<tr><th style="width:110px" onclick="setSort('room')">Room</th><th onclick="setSort('work')">Work</th><th onclick="setSort('sub')">Sub Work</th><th onclick="setSort('status')">Status</th><th>Status Image</th><th>Purpose</th><th>Remarks</th></tr>`;

  const selectAllRooms = document.getElementById('selectAllRooms').checked;
  const selectAllWorks = document.getElementById('selectAllWorks').checked;
  let roomFilter = '', workFilter = '';
  if(!selectAllRooms) roomFilter = (document.getElementById('filterRoom').value||'').trim();
  if(!selectAllWorks) workFilter = (document.getElementById('filterWork').value||'').trim().toLowerCase();
  const statusFilter = (document.getElementById('filterStatus').value||'').trim().toLowerCase();
  const search = (document.getElementById('filterSearch').value||'').trim().toLowerCase();

  const rows = [];
  fullRooms.forEach(room=>{
    // room filter
    if(roomFilter){
      if(roomFilter.length===1){
        if(!room.startsWith(roomFilter)) return;
      } else {
        if(room !== roomFilter) return;
      }
    }
    const works = roomData[room]?.works || {};
    if(Object.keys(works).length===0){
      if(search && !room.toLowerCase().includes(search)) return;
      rows.push({ room, work:'', sub:'', status:'', purpose:'', remarks:'', workKey:'', subIdx:undefined });
    } else {
      Object.keys(works).forEach(work=>{
        if(workFilter && work.toLowerCase().indexOf(workFilter)===-1) return;
        const subs = works[work] || [];
        if(subs.length===0){
          if(statusFilter) return;
          if(search && (room+' '+work).toLowerCase().indexOf(search)===-1) return;
          rows.push({ room, work, sub:'', status:'', purpose:'', remarks:'', workKey:work, subIdx:undefined });
        } else {
          subs.forEach((sub, idx)=>{
            const s = (sub.status||'').toLowerCase();
            if(statusFilter && s !== statusFilter) return;
            const hay = [room,work,sub.name||'',sub.purpose||'',sub.remarks||''].join(' ').toLowerCase();
            if(search && hay.indexOf(search)===-1) return;
            rows.push({ room, work, sub: sub.name||'', status: sub.status||'', purpose: sub.purpose||'', remarks: sub.remarks||'', workKey:work, subIdx:idx });
          });
        }
      });
    }
  });

  // sorting
  rows.sort((a,b)=>{
    const key = currentSort.col;
    if(key==='room'){ const ia = desiredOrder.indexOf(a.room), ib = desiredOrder.indexOf(b.room); return (ia-ib)*currentSort.dir; }
    const da = (a[key]||'').toString().toLowerCase(), db = (b[key]||'').toString().toLowerCase();
    if(da<db) return -1*currentSort.dir; if(da>db) return 1*currentSort.dir; return 0;
  });

  const frag = document.createDocumentFragment();
  rows.forEach(r=>{
    const tr = document.createElement('tr');
    const ls = (r.status||'').toLowerCase();
    if(ls.includes('completed')) tr.style.background='rgba(16,185,129,0.04)';
    else if(ls.includes('work')) tr.style.background='rgba(245,158,11,0.04)';
    else if(ls.includes('pending')) tr.style.background='rgba(239,68,68,0.02)';
    tr.dataset.room = r.room;
    if(r.workKey) tr.dataset.work = r.workKey;
    if(r.subIdx !== undefined) tr.dataset.subidx = r.subIdx;

    const editAttr = (currentRole !== 'viewer');

    function cellHTML(content, editable=false, cls=''){ if(editable && editAttr) return `<div class="content-editable ${cls}" contenteditable="true">${escapeHtml(content)}</div>`; return `<div>${escapeHtml(content)}</div>`; }

    // status image: prefer sub-work image, else work-level image, else show "No Image"
    let statusImgSrc = '';
    if(r.subIdx !== undefined && r.workKey && roomData[r.room] && roomData[r.room].works && roomData[r.room].works[r.workKey] && roomData[r.room].works[r.workKey][r.subIdx] && roomData[r.room].works[r.workKey][r.subIdx].images && roomData[r.room].works[r.workKey][r.subIdx].images.length>0){
      statusImgSrc = roomData[r.room].works[r.workKey][r.subIdx].images[0];
    } else if(r.workKey && roomData[r.room] && roomData[r.room].works && roomData[r.room].works[r.workKey] && roomData[r.room].works[r.workKey]._images && roomData[r.room].works[r.workKey]._images.length>0){
      statusImgSrc = roomData[r.room].works[r.workKey]._images[0];
    }
    const statusImgHtml = statusImgSrc ? `<div class="img-wrap"><img src="${statusImgSrc}" class="room-image"/><span class="delete-icon" title="Delete image" data-room="${r.room}" data-work="${r.workKey||''}" data-sub="${r.subIdx!==undefined?r.subIdx:''}" data-level="${r.subIdx!==undefined?'sub':'work'}">🗑️</span></div>` : `<div class="small-muted">No Image</div>`;

    // camera button: upload to sub-work if sub exists; else to work if work exists; else disabled
    let camHtml = '';
    if(r.subIdx !== undefined && r.workKey){
      camHtml = `<button class="camera-btn" data-room="${r.room}" data-work="${r.workKey||''}" data-sub="${r.subIdx}" title="Upload sub-work image">📷</button>`;
    } else if(r.workKey){
      camHtml = `<button class="camera-btn" data-room="${r.room}" data-work="${r.workKey||''}" data-sub="" title="Upload work image">📷</button>`;
    } else {
      camHtml = `<button class="camera-btn disabled-btn" disabled title="Add work/sub-work first">📷</button>`;
    }

    tr.innerHTML = `<td>${escapeHtml(r.room)}</td>
      <td>${cellHTML(r.work,true,'work-cell')}</td>
      <td>${cellHTML(r.sub,true,'sub-cell')}</td>
      <td><select class="status-select"><option></option><option ${r.status==='Completed'?'selected':''}>Completed</option><option ${r.status==='Work in Progress'?'selected':''}>Work in Progress</option><option ${r.status==='Pending'?'selected':''}>Pending</option></select></td>
      <td style="display:flex;gap:8px;align-items:center">${statusImgHtml}${camHtml}</td>
      <td>${cellHTML(r.purpose,true,'purpose-cell')}</td>
      <td>${cellHTML(r.remarks,true,'remarks-cell')}</td>`;

    frag.appendChild(tr);
  });

  body.innerHTML=''; body.appendChild(frag);
  attachViewHandlers();
}

/* escape helper */
function escapeHtml(s){ return (s||'').toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

/* attach handlers after table render */
function attachViewHandlers(){
  const table = document.getElementById('viewTable');

  // status change (applies to sub-work)
  table.querySelectorAll('.status-select').forEach(sel=>{
    sel.onchange = function(){
      const tr = this.closest('tr'); const room = tr.dataset.room; const workKey = tr.dataset.work; const subIdx = tr.dataset.subidx;
      const newStatus = this.value;
      if(room && workKey && subIdx!==undefined){
        if(currentRole==='viewer'){ alert('Read-only'); renderViewTable(); return; }
        const arr = roomData[room].works[workKey];
        if(arr && arr[parseInt(subIdx)]){ arr[parseInt(subIdx)].status = newStatus; saveState(); addLog(`Status ${newStatus} on ${room} ${workKey}/${arr[parseInt(subIdx)].name}`); renderStats(); }
      }
    };
  });

  // editable content: purpose & remarks & work & sub
  ['purpose-cell','remarks-cell'].forEach(cls=>{
    table.querySelectorAll('.'+cls).forEach(el=>{
      el.onblur = function(){
        const tr = this.closest('tr'); const room = tr.dataset.room; const workKey = tr.dataset.work; const subIdx = tr.dataset.subidx;
        if(room && workKey && subIdx!==undefined){
          if(currentRole==='viewer'){ renderViewTable(); return; }
          const arr = roomData[room].works[workKey];
          if(arr && arr[parseInt(subIdx)]){ if(cls==='purpose-cell') arr[parseInt(subIdx)].purpose = this.innerText.trim(); else arr[parseInt(subIdx)].remarks = this.innerText.trim(); saveState(); addLog(`${cls==='purpose-cell'?'Purpose':'Remarks'} updated for ${room} ${workKey}/${arr[parseInt(subIdx)].name}`); }
        }
      };
    });
  });

  if(currentRole!=='viewer'){
    // rename work by editing work-cell
    table.querySelectorAll('.work-cell').forEach(el=>{
      el.onblur = function(){
        const newWork = this.innerText.trim(); const tr = this.closest('tr'); const room = tr.dataset.room; const oldWork = tr.dataset.work; const subIdx = tr.dataset.subidx;
        if(room && oldWork && newWork && oldWork!==newWork){
          if(!roomData[room]) roomData[room] = { works:{} };
          const works = roomData[room].works;
          works[newWork] = works[oldWork];
          if(!works[newWork]._images) works[newWork]._images = works[oldWork]._images || [];
          delete works[oldWork];
          saveState(); renderViewTable(); populateFilterOptions(); addLog(`Renamed work ${oldWork} -> ${newWork} in ${room}`);
        }
      };
    });

    // rename sub by editing sub-cell
    table.querySelectorAll('.sub-cell').forEach(el=>{
      el.onblur = function(){
        const newSub = this.innerText.trim(); const tr = this.closest('tr'); const room = tr.dataset.room; const workKey = tr.dataset.work; const subIdx = tr.dataset.subidx;
        if(room && workKey && subIdx!==undefined){
          const arr = roomData[room].works[workKey];
          if(arr && arr[parseInt(subIdx)]){ arr[parseInt(subIdx)].name = newSub; saveState(); renderViewTable(); addLog(`Renamed sub ${newSub} in ${room}/${workKey}`); }
        }
      };
    });
  }

  // camera buttons: upload to sub-work if sub specified, else to work if present
  table.querySelectorAll('.camera-btn').forEach(btn=>{
    if(btn.disabled) return;
    btn.onclick = (e)=>{
      const room = btn.dataset.room; if(!room) return;
      const workKey = btn.dataset.work; const sub = btn.dataset.sub;
      if(currentRole==='viewer'){ alert('Only staff/admin can add status image (View)'); return; }
      const input = document.createElement('input'); input.type='file'; input.accept='image/*';
      input.onchange = (ev)=>{
        const f = ev.target.files[0]; if(!f) return;
        const r = new FileReader(); r.onload = (evt)=>{
          if(workKey && sub!==''){ // attach to sub-work images
            if(!roomData[room]) roomData[room] = { works:{} };
            if(!roomData[room].works[workKey]) roomData[room].works[workKey] = [];
            if(!roomData[room].works[workKey]._images) roomData[room].works[workKey]._images = [];
            const idx = parseInt(sub);
            if(!roomData[room].works[workKey][idx]) roomData[room].works[workKey][idx] = { name:'', status:'', purpose:'', remarks:'', images:[] };
            if(!roomData[room].works[workKey][idx].images) roomData[room].works[workKey][idx].images = [];
            roomData[room].works[workKey][idx].images.unshift(evt.target.result);
            addLog(`Sub-work image added to ${room} ${workKey}/${roomData[room].works[workKey][idx].name}`);
          } else if(workKey){
            // attach to work-level images
            if(!roomData[room]) roomData[room] = { works:{} };
            if(!roomData[room].works[workKey]) roomData[room].works[workKey] = [];
            if(!roomData[room].works[workKey]._images) roomData[room].works[workKey]._images = [];
            roomData[room].works[workKey]._images.unshift(evt.target.result);
            addLog(`Work image added to ${room} ${workKey}`);
          }
          saveState(); renderViewTable(); showToast('Image saved');
        }; r.readAsDataURL(f);
      };
      input.click();
    };
  });

  // delete icons in view table (work-level or sub-level)
  table.querySelectorAll('.delete-icon').forEach(ic=>{
    ic.addEventListener('click', ()=>{
      const level = ic.dataset.level;
      const room = ic.dataset.room;
      const work = ic.dataset.work;
      if(level==='work'){
        if(!confirm('Delete work image?')) return;
        const arr = roomData[room].works[work];
        if(arr && arr._images && arr._images.length>0){ arr._images.splice(0,1); saveState(); renderViewTable(); addLog(`Deleted work-level image for ${room} ${work}`); showToast('Image deleted'); }
      } else if(level==='sub'){
        const subIdx = parseInt(ic.dataset.sub);
        if(!confirm('Delete sub-work image?')) return;
        const sub = roomData[room].works[work][subIdx];
        if(sub && sub.images && sub.images.length>0){ sub.images.splice(0,1); saveState(); renderViewTable(); addLog(`Deleted sub-work image for ${room} ${work}/${sub.name}`); showToast('Image deleted'); }
      }
    });
  });
}

/* sorting helper */
function setSort(col){
  if(currentSort.col===col) currentSort.dir *= -1; else { currentSort.col = col; currentSort.dir = 1; }
  renderViewTable();
}

/* ----------------- Global work panel ----------------- */
function renderGlobalWorkPanel(){
  const el = document.getElementById('globalWorkList'); el.innerHTML = '';
  const map = {};
  Object.keys(roomData).forEach(room=>{
    const works = roomData[room].works || {};
    Object.keys(works).forEach(w=>{
      if(!w || !w.trim()) return;
      map[w] = map[w] || { rooms:0, totalSubs:0, completed:0 };
      map[w].rooms++;
      works[w].forEach(s=>{ map[w].totalSubs++; if((s.status||'').toLowerCase().includes('completed')) map[w].completed++; });
    });
  });
  const q = document.getElementById('roomSearch').value.trim().toLowerCase();
  Object.keys(map).sort().forEach(w=>{
    if(q && w.toLowerCase().indexOf(q)===-1) return;
    const item = map[w]; const pct = item.totalSubs ? Math.round((item.completed/item.totalSubs)*100) : 0;
    const row = document.createElement('div'); row.style.display='flex'; row.style.justifyContent='space-between'; row.style.padding='6px 0'; row.style.cursor='pointer';
    row.innerHTML = `<div style="font-weight:600">${w}</div><div class="small-muted">${item.rooms} rooms • ${pct}%</div>`;
    row.addEventListener('click', ()=>{ document.getElementById('filterWork').value = w; renderViewTable(); showView(); showToast('Filtered by work '+w); });
    el.appendChild(row);
  });
}

/* ----------------- Activity log ----------------- */
function renderActivityLog(){
  const el = document.getElementById('activityLog'); el.innerHTML = '';
  activityLog.forEach(it=>{
    const d = new Date(it.time);
    const row = document.createElement('div'); row.style.fontSize='13px'; row.style.marginBottom='6px';
    row.innerHTML = `<strong>${d.toLocaleString()}</strong> — ${it.text}`;
    el.appendChild(row);
  });
}

/* ----------------- Exports / Imports ----------------- */
function exportToXLSX(){
  const rows = []; rows.push(['Room','Work','Sub Work','Status','Purpose','Remarks']);
  fullRooms.forEach(r=>{
    const works = roomData[r]?.works || {};
    if(Object.keys(works).length===0) rows.push([r,'','','','','']);
    else Object.keys(works).forEach(w=>{
      const subs = works[w] || [];
      if(subs.length===0) rows.push([r,w,'','','','']);
      else subs.forEach(s=> rows.push([r,w,s.name||'',s.status||'',s.purpose||'',s.remarks||'']));
    });
  });
  const ws = XLSX.utils.aoa_to_sheet(rows); const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Rooms'); XLSX.writeFile(wb, 'rooms_export.xlsx');
}
function exportJSON(){
  const data = { roomData, activityLog, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data,null,2)], { type:'application/json' });
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `rooms_backup_${new Date().toISOString().slice(0,19).replace(/[:T]/g,'_')}.json`; a.click(); URL.revokeObjectURL(url);
}
function handleImport(ev){
  const f = ev.target.files[0]; if(!f) return;
  const reader = new FileReader(); reader.onload = (e)=>{
    try{
      const obj = JSON.parse(e.target.result);
      if(obj.roomData) roomData = obj.roomData;
      if(obj.activityLog) activityLog = obj.activityLog;
      saveState(); saveLog(); populateFilterOptions(); renderGlobalWorkPanel(); renderViewTable(); renderStats(); renderActivityLog();
      showToast('Data restored');
    } catch(err){ alert('Invalid JSON'); }
  }; reader.readAsText(f);
}

/* ----------------- Search utilities ----------------- */
function highlightSearch(){
  const q = (document.getElementById('roomSearch').value||'').trim().toLowerCase();
  document.querySelectorAll('.room-card').forEach(rc=>{
    const txt = (rc.innerText||'').toLowerCase();
    if(!q) rc.style.boxShadow='';
    else if(txt.indexOf(q)!==-1) rc.style.boxShadow='0 0 0 4px rgba(0,102,204,0.12)';
    else rc.style.boxShadow='';
  });
}
function jumpToMatch(){
  const q = (document.getElementById('roomSearch').value||'').trim().toLowerCase(); if(!q) return;
  const el = Array.from(document.querySelectorAll('.room-card')).find(r=> (r.innerText||'').toLowerCase().includes(q));
  if(el){ el.scrollIntoView({ behavior:'smooth', block:'center' }); el.style.boxShadow='0 0 0 6px rgba(0,102,204,0.14)'; setTimeout(()=>el.style.boxShadow='',1600); showToast('Jumped to match'); }
}

/* ----------------- Dashboard status filtering & helpers ----------------- */
function getRoomSummary(room){
  const cats = roomData[room]?.works || {}; let total=0, completed=0, wip=0, pending=0;
  Object.values(cats).forEach(arr=>arr.forEach(i=>{ total++; const s=(i.status||'').toLowerCase(); if(s.includes('completed')) completed++; else if(s.includes('work')) wip++; else if(s.includes('pending')) pending++; }));
  let status='No works'; if(total>0){ if(completed===total) status='All completed'; else status=`${completed} of ${total} done`; }
  return { total, completed, wip, pending, status };
}

function showStatusRooms(type){
  const rc = document.getElementById('roomsContainer'); rc.innerHTML = `<h4>${type} Rooms</h4>`;
  const list = [];
  fullRooms.forEach(room=>{
    const works = roomData[room]?.works || {}; let total=0, completed=0, wip=0, pending=0;
    Object.values(works).forEach(arr=>arr.forEach(s=>{ total++; const st=(s.status||'').toLowerCase(); if(st.includes('completed')) completed++; else if(st.includes('work')) wip++; else if(st.includes('pending')) pending++; }));
    if(type==='Completed' && total>0 && completed===total) list.push(room);
    else if(type==='Work in Progress' && wip>0) list.push(room);
    else if(type==='Pending' && pending>0 && completed===0 && wip===0) list.push(room);
  });
  if(list.length===0){ rc.appendChild(document.createElement('div')).innerText = 'No rooms'; return; }
  const grid = document.createElement('div'); grid.className='room-grid';
  list.forEach(r=>{
    const info = getRoomSummary(r); const percent = info.total ? Math.round((info.completed/info.total)*100) : 0;
    const card = document.createElement('div'); card.className='room-card';
    card.innerHTML = `<strong>${r}</strong><div class="small-muted">${info.total} works</div><div class="room-progress"><div style="width:${percent}%;height:100%;background:${info.total && info.completed===info.total? 'var(--green)': (info.completed>0? 'var(--yellow)': 'var(--red)') }"></div></div>
      <div style="margin-top:8px"><button class="btn" data-room="${r}" data-action="open">Open</button></div>`;
    grid.appendChild(card);
  });
  rc.appendChild(grid);
  rc.querySelectorAll('button[data-action="open"]').forEach(b=>b.addEventListener('click', e=> openRoomModal(e.target.dataset.room)));
}

/* showRoomsList used by clicking Total Rooms */
function showRoomsList(list){
  const rc = document.getElementById('roomsContainer'); rc.innerHTML = `<h4>All Rooms</h4>`;
  const grid = document.createElement('div'); grid.className='room-grid';
  list.forEach(r=>{
    const info = getRoomSummary(r); const percent = info.total ? Math.round((info.completed/info.total)*100) : 0;
    const color = info.total===0 ? 'rgba(0,0,0,0.06)' : (info.completed===info.total ? 'var(--green)' : (info.completed>0 ? 'var(--yellow)' : 'var(--red)'));
    const card = document.createElement('div'); card.className='room-card';
    card.innerHTML = `<strong>${r}</strong><div class="small-muted">${info.total} works</div><div class="room-progress"><div style="width:${percent}%;height:100%;background:${color}"></div></div>
      <div style="margin-top:8px"><button class="btn" data-room="${r}" data-action="open">Open</button></div>`;
    grid.appendChild(card);
  });
  rc.appendChild(grid);
  rc.querySelectorAll('button[data-action="open"]').forEach(b=>b.addEventListener('click', e=> openRoomModal(e.target.dataset.room)));
}

/* ----------------- Utility ----------------- */
function clearFilters(){
  document.getElementById('filterRoom').value=''; document.getElementById('filterWork').value=''; document.getElementById('filterStatus').value=''; document.getElementById('filterSearch').value='';
  document.getElementById('selectAllRooms').checked=false; document.getElementById('selectAllWorks').checked=false;
  document.getElementById('filterRoom').removeAttribute('disabled'); document.getElementById('filterWork').removeAttribute('disabled');
  renderViewTable();
}
function showView(){ document.getElementById('dashboardPanel').style.display='none'; document.getElementById('viewPanel').style.display='block'; renderViewTable(); renderStats(); renderGlobalWorkPanel(); populateFilterOptions(); }

/* open dashboard (with optional password to enable admin/staff actions) */
function openDashboard(){
  const pass = prompt('Enter Dashboard password for admin/staff (cancel for Viewer view)');
  if(pass===null){ currentRole='viewer'; renderBlocks(); document.getElementById('dashboardPanel').style.display='block'; document.getElementById('viewPanel').style.display='none'; return; }
  if(pass===ADMIN_PASS){ currentRole='admin'; addLog('Admin authenticated for Dashboard'); }
  else if(pass===STAFF_PASS){ currentRole='staff'; addLog('Staff authenticated for Dashboard'); }
  else { alert('Incorrect password'); return; }
  renderBlocks(); document.getElementById('dashboardPanel').style.display='block'; document.getElementById('viewPanel').style.display='none';
}

/* ----------------- Initial population & small fixes ----------------- */
populateFilterOptions();
renderGlobalWorkPanel();
renderStats();
renderViewTable();
renderActivityLog();

/* Save on unload */
window.addEventListener('beforeunload', ()=>{ saveState(); saveLog(); });

